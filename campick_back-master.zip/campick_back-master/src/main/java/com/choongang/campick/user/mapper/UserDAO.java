package com.choongang.campick.user.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserDAO {
	
	
	//test입니다 삭제하고 진행해 주세요
	void test();

}
