package com.choongang.campick;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampickApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampickApplication.class, args);
	}

}
