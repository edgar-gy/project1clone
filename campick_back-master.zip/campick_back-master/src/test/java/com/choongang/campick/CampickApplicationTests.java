package com.choongang.campick;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampickApplicationTests {

	@Test
	void contextLoads() {
	}

}
